function Menu() {
  return <h1>Menu</h1>;
}

export default Menu;
